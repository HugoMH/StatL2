# Partie contenant la programmation de la fonctin de comparaison d'échantillon par un stest de Student
# Il vous suffit de copier coller ce script dans votre console R studio et de la faire exécuter

check.test = function(test,samplesize,sampledist1,sampledist2,count) 
{
  resultat <- rep(0,count)
  for (i in 1:count) 
    resultat[i] <- test(sampledist1(samplesize),sampledist2(samplesize))
  resultat
}

t.test.pvalue = function(x,y) t.test(x,y)$p.value

normalea_egale = function(x) rnorm(x,1.6,0.4)
normalea_different = function(x) rnorm(x,2,0.4)


expalea_egale = function(x) rexp(x,1/1.6)
expalea_different = function(x) rexp(x,1/2)


graph_pvalue=function(taille_echantillon,echantillon,nombre_loi_simuler,loi_echantillon)
{
  if(echantillon=="egaux" & loi_echantillon=="normale")
    plot(factor(check.test(t.test.pvalue,taille_echantillon,normalea_egale,normalea_egale,nombre_loi_simuler) > 0.05),main="Echantillons égaux, loi Normale")
  if(echantillon=="different" & loi_echantillon=="normale")
    plot(factor(check.test(t.test.pvalue,taille_echantillon,normalea_egale,normalea_different,nombre_loi_simuler) > 0.05),main="Echantillons différents, loi Normale")
  if(echantillon=="egaux" & loi_echantillon=="exponentielle")
    plot(factor(check.test(t.test.pvalue,taille_echantillon,expalea_egale,expalea_egale,nombre_loi_simuler) > 0.05),main="Echantillons égaux, loi exponentielle")
  if(echantillon=="different" & loi_echantillon=="exponentielle")
    plot(factor(check.test(t.test.pvalue,taille_echantillon,expalea_egale,expalea_different,nombre_loi_simuler) > 0.05),main="Echantillons différents, loi exponentielle")
     }


